<?php

namespace MageArray\Wholesale\Model\Customer\Attribute\Frontend;
class FileUpload extends \Magento\Eav\Model\Entity\Attribute\Frontend\AbstractFrontend
{

}
